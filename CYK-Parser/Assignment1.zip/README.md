# Artificial-Intelligence

1. Grammar and Lexicon in grammar.txt
2. Enter all phrases to test in phrases.txt
3. Run 'Python main.py' to run program, will output to console